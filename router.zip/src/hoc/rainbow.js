import React from 'react'

const rainbow=(Wrapped) => {

    const colours = ['red', 'pink', 'blue', 'yellow', 'green'];
    const randomColour= colours[Math.floor(Math.random()*5)];
    const className= randomColour + '-text'

    return (props) => {
        return(
            <div className={className}>
                <Wrapped {...props}/>
            </div>
        )
    }

}

export default rainbow