import React from 'react'

const Contact  = (props) => {
    // setTimeout(() => {
    //  props.history.push('./')  
    // }, 2000)
    return(
        <div className='container'>
            <h4 className="centre">Contact </h4>
            <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati et adipisci dolores ut deleniti nulla assumenda nam dignissimos maiores earum, minima libero similique amet fugiat voluptates non culpa ab fugit corporis quae provident magnam incidunt. Officiis maiores architecto modi aliquam?</p>
        </div>
    )
}

export default Contact 