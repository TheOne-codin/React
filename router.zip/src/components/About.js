import React from 'react'
import rainbow from '../hoc/rainbow'
const About = () => {
    return(
        <div className='container'>
            <h4 className="centre">About</h4>
            <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati et adipisci dolores ut deleniti nulla assumenda nam dignissimos maiores earum, minima libero similique amet fugiat voluptates non culpa ab fugit corporis quae provident magnam incidunt. Officiis maiores architecto modi aliquam?</p>
        </div>
    )
}

export default rainbow(About)